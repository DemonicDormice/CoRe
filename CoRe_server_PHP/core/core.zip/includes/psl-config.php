<?php 
define("HOST", "localhost");
define("USER", "d02852e4"); 
define("PASSWORD", "dadPdCoRedb");
define("DATABASE", "d02852e4");
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", true);    // Use HTTPS


?>